"""Re-run the pinned small experiment in a new directory (tested on Linux).
Never replaces an existing result directory. No network access is required.
"""
import argparse,shutil,subprocess,os,sys,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main(out):
    out=out.resolve()
    if out.exists():raise FileExistsError(out)
    if out==ROOT or ROOT in out.parents:raise ValueError('Use a sibling/outside output folder')
    shutil.copytree(ROOT,out,ignore=shutil.ignore_patterns('results','__pycache__','.pytest_cache','CHECKSUMS.sha256'))
    (out/'results').mkdir()
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=str(out/'vendor')+os.pathsep+str(out))
    def call(args,log):
        with (out/'results'/log).open('w') as f:
            subprocess.run([sys.executable,*args],cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    call(['-m','pytest','tests','-q','--junitxml=results/tests_before.xml'],'tests_before.log')
    call(['replay_gate.py'],'reproduction_gate.log')
    for seed in range(79020000,79020008):
        print('Running seed',seed,flush=True)
        call(['run_seed.py','--seed',str(seed)],f'run_{seed}.log')
    call(['audit_results.py'],'postrun_audit.log')
    call(['-m','pytest','tests','-q','--junitxml=results/tests_after.xml'],'tests_after.log')
    # Exact matching of game/model snapshots and all frozen trial actions and
    # outcomes against the retained reference. Time columns are not compared.
    mismatches=[];checked=0
    for seed in range(79020000,79020008):
        for mode in ('A_frozen','B_record_replan','C_record_replan_explore'):
            for b in (0,1000,5000):
                for prefix in ('snapshot','evaluation'):
                    rel=Path(str(seed))/mode/f'{prefix}_{b}.json'
                    left=json.loads((ROOT/'results'/rel).read_text())
                    right=json.loads((out/'results'/rel).read_text())
                    if left!=right:mismatches.append(str(rel))
                    checked+=1
    result={'status':'PASS' if not mismatches else 'FAIL','matched_snapshot_and_evaluation_files':checked-len(mismatches),
            'checked_files':checked,'mismatches':mismatches,'note':'Exact JSON values; no time data in compared files'}
    (out/'results/reproduction_against_bundle.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));assert not mismatches
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);main(p.parse_args().output)

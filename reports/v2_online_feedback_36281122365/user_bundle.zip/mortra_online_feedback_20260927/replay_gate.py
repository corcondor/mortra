"""No new policy outcomes: check source/input integrity and frozen replay.
Original historical actions, states, success counts, and loaded snapshots must
match exactly. Float-score bit equality is not asserted across platforms.
"""
import json,gzip,hashlib,collections,time
from pathlib import Path
from online_feedback import *

def main():
    t=time.perf_counter(); rows=[]
    for seed in range(79020000,79020008):
        folder=ROOT/'inputs'/str(seed)
        game,learner=load_case(seed)
        metrics=json.loads((folder/'metrics.json').read_text())
        with gzip.open(folder/'actions.jsonl.gz','rt',encoding='utf8') as f:
            actions=[json.loads(x) for x in f]
        groups=collections.defaultdict(list)
        for x in actions:groups[(x['phase'],x['trial'])].append(x)
        # Replaying observed traces is post-hoc checking, not policy information.
        trace_count=0
        for key,rr in groups.items():
            state=game.get_initial_state()
            for r in rr:
                assert tuple(r['state'])==state,(seed,key,'state')
                state=game.step(state,r['action'])
                assert tuple(r['next_state'])==state,(seed,key,'next_state')
                trace_count+=1
        recreated=v2.StructuralLearner()
        for r in groups[('training',None)]:
            u=recreated.get_or_add_id(tuple(r['state']));v=recreated.get_or_add_id(tuple(r['next_state']))
            recreated.record_transition(u,r['action'],v)
        assert json_hash(learner_data(recreated))==json_hash(learner_data(learner)),(seed,'snapshot')
        ev=evaluate_snapshot(game,learner)
        diffs=[]
        for r in ev['replays']:
            old=groups[('mortra',r['trial'])]
            states=[list(game.get_initial_state())]+[x['next_state'] for x in old]
            if r['actions']!=[x['action'] for x in old]: diffs.append({'trial':r['trial'],'field':'actions'})
            if [list(x) for x in r['states']]!=states: diffs.append({'trial':r['trial'],'field':'states'})
            if r['reached_goal'] != game.is_goal(tuple(states[-1])): diffs.append({'trial':r['trial'],'field':'success'})
        assert ev['successes']==metrics['successes'],(seed,ev['successes'],metrics['successes'])
        row={'seed':seed,'frozen_successes':ev['successes'],'trials':50,
             'mean_capped_steps':ev['mean_capped_steps'],'action_state_mismatches':diffs,
             'loaded_model_equals_recorded_training':True,'replayed_original_actions':trace_count,
             'original_mortra_actions':sum(len(groups[('mortra',i)]) for i in range(50)),
             'game_sha256':json_hash(game.to_dict()),'snapshot_sha256':json_hash(learner_data(learner))}
        rows.append(row);print(json.dumps(row),flush=True)
    result={'status':'PASS' if all(not r['action_state_mismatches'] for r in rows) else 'FAIL',
            'worlds':8,'reproduction_trials':400,'rows':rows,'seconds':time.perf_counter()-t,
            'scope':'original frozen self-play on saved initial snapshots; no new games, no changed policies'}
    dump(ROOT/'results/reproduction_gate.json',result)
    assert result['status']=='PASS'
if __name__=='__main__':main()

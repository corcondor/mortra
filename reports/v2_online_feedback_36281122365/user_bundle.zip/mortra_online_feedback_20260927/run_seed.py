"""Run one complete three-arm comparison on an unchanged saved initial game."""
import argparse,hashlib,json,platform,resource,sys,time,traceback
from pathlib import Path
import numpy,scipy
import online_feedback as o


def verify_sources():
    manifest=json.loads((o.ROOT/'source_manifest_before.json').read_text())
    bad=[]
    for path,d in manifest.items():
        actual=hashlib.sha256((o.ROOT/path).read_bytes()).hexdigest()
        if actual!=d:bad.append(path)
    if bad:raise RuntimeError(f'Frozen source mismatch: {bad}')
    return hashlib.sha256((o.ROOT/'source_manifest_before.json').read_bytes()).hexdigest()


def main(seed):
    protocol=json.loads((o.ROOT/'protocol_before.json').read_text())
    if seed not in protocol['seeds']:raise ValueError('Unregistered development seed')
    assert json.loads((o.ROOT/'results/reproduction_gate.json').read_text())['status']=='PASS'
    digest=verify_sources();out=o.ROOT/'results'/str(seed);out.mkdir(exist_ok=False)
    g,l=o.load_case(seed);start=time.perf_counter()
    rows=[]
    try:
        for mode in protocol['conditions']:
            d=out/mode;d.mkdir()
            t=time.perf_counter()
            result=o.run_feedback(g,l,mode,checkpoints=tuple(protocol['checkpoints']),
                                  horizon=protocol['horizon'],trials=protocol['eval_trials'],output=d)
            for r in result['rows']:r['seed']=seed
            rows+=result['rows']
            print(json.dumps({'seed':seed,'condition':mode,
              'checkpoints':[{k:r[k] for k in ['additional_actions','successes','mean_capped_steps','known_states','known_pairs','known_goal_states','selector_calls','first_goal_observation_action']} for r in result['rows']],
              'seconds':time.perf_counter()-t}),flush=True)
        verify_sources()
        o.dump(out/'completed.json',{'status':'COMPLETE_DEVELOPMENT_COMPARISON','seed':seed,'rows':rows,
               'source_manifest_sha256':digest,'source_unchanged':True,'seconds':time.perf_counter()-start,
               'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
               'environment':{'python':sys.version,'platform':platform.platform(),'numpy':numpy.__version__,'scipy':scipy.__version__}})
    except BaseException as exc:
        o.dump(out/'incomplete.json',{'seed':seed,'status':'RUN_INCOMPLETE','exception':repr(exc),'traceback':traceback.format_exc()})
        raise
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True);main(p.parse_args().seed)

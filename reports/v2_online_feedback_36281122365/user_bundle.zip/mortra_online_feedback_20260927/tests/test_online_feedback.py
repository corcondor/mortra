import copy, json, sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import online_feedback as o


def line_game(goal=2):
    g=o.v2.MicroGame(width=5,height=3)
    g.start_pos=(1,1);g.goal_pos=(goal,1)
    g.walls={(x,y) for x in range(5) for y in range(3) if y!=1 or x in (0,4)}
    return g


def empty(g):
    l=o.v2.StructuralLearner();l.get_or_add_id(g.get_initial_state());return l


def record_right_path(g):
    l=empty(g);s=g.get_initial_state()
    for _ in range(2):
        t=g.step(s,3);u=l.get_or_add_id(s);v=l.get_or_add_id(t);l.record_transition(u,3,v);s=t
    return l


@pytest.mark.parametrize('trial',range(10))
def test_legacy_fallback_is_trial_mod_5(trial):
    g=line_game();l=empty(g)
    a,f,_=o.legacy_choose(l,g.get_initial_state(),np.zeros(1),trial)
    assert f and a==trial%5


def test_goal_discovered_and_field_recomputed():
    g=line_game();l=empty(g)
    r=o.run_feedback(g,l,o.MODES[2],checkpoints=(0,4,20),horizon=5,trials=4)
    assert r['rows'][1]['first_goal_observation_action']==4
    assert r['rows'][1]['known_goal_states']>0
    assert any(e['after_action']==4 and e['goals']>0 for e in r['solver_events'])
    assert r['evaluations'][4]['successes']==4
    assert r['rows'][-1]['selector_calls']==4


@pytest.mark.parametrize('mode',o.MODES)
def test_exact_budget_and_immutable_input(mode):
    g=line_game();l=empty(g);before=o.json_hash(o.learner_data(l));gh=o.json_hash(g.to_dict())
    r=o.run_feedback(g,l,mode,checkpoints=(0,4,23),horizon=5,trials=3)
    assert r['exact_additional_actions']==23
    assert len(r['training_trace'])==23
    assert o.json_hash(o.learner_data(l))==before
    assert o.json_hash(g.to_dict())==gh
    assert o.json_hash(r['snapshots'][0])==before
    assert r['rows'][-1]['recorded_visits']==(0 if mode==o.MODES[0] else 23)


@pytest.mark.parametrize('mode',o.MODES[1:])
def test_only_observed_transitions_recorded_no_reset_edges(mode):
    g=line_game();l=empty(g)
    r=o.run_feedback(g,l,mode,checkpoints=(0,12,50),horizon=5,trials=3)
    replay=copy.deepcopy(l)
    for row in r['training_trace']:
        s,t=tuple(row['state']),tuple(row['next_state']); assert g.step(s,row['action'])==t
        u=replay.get_or_add_id(s);v=replay.get_or_add_id(t);replay.record_transition(u,row['action'],v)
    assert o.json_hash(o.learner_data(replay))==o.json_hash(r['snapshots'][50])
    assert sum(replay.action_visits.values())==50
    assert r['rows'][-1]['reset_calls']>1


def test_record_only_retains_old_fallback():
    g=line_game();r=o.run_feedback(g,empty(g),o.MODES[1],checkpoints=(0,40),horizon=5,trials=3)
    for row in r['training_trace']:
        if row['fallback']:assert row['action']==row['trial']%5
        assert not row['selector_called']


def test_explorer_called_only_in_fallback_and_uniform_sources():
    g=line_game();r=o.run_feedback(g,empty(g),o.MODES[2],checkpoints=(0,40),horizon=5,trials=3)
    for row in r['training_trace']:
        assert row['selector_called']==row['fallback']
        if row['selector_called']:
            t=row['telemetry']
            assert t['source_min']==t['source_max']==1
            assert not t['task_signal_available']
    assert r['rows'][-1]['selector_calls']>0


def test_singleton_task_cannot_leak_goal_or_progress():
    m=o.TaskBlindSelector('virtual_frontier').memory
    with pytest.raises(AssertionError): m.progress(0)
    with pytest.raises(AssertionError): m.accepting(0)


def test_frozen_evaluation_does_not_call_recorder(monkeypatch):
    g=line_game(3);l=record_right_path(g)
    def forbidden(*a,**k):raise RuntimeError('evaluation modified learner')
    monkeypatch.setattr(o.v2.StructuralLearner,'record_transition',forbidden)
    assert o.evaluate_snapshot(g,l,trials=4,horizon=2)['successes']==4


def test_last_action_goal_counted_once():
    g=line_game(3);l=record_right_path(g)
    r=o.evaluate_snapshot(g,l,trials=7,horizon=2)
    assert r['successes']==7 and all(len(x['actions'])==2 for x in r['replays'])


def test_zero_action_terminal_evaluation():
    g=line_game(1);l=empty(g)
    r=o.evaluate_snapshot(g,l,trials=3,horizon=0)
    assert r['successes']==3 and r['actual_actions']==0


def test_positive_budget_on_terminal_reset_rejected():
    g=line_game(1)
    with pytest.raises(ValueError,match='terminal'):
        o.run_feedback(g,empty(g),o.MODES[2],checkpoints=(0,2))


def test_checkpoint_does_not_change_learning():
    g=line_game();l=empty(g)
    a=o.run_feedback(g,l,o.MODES[2],checkpoints=(0,4,30),horizon=5,trials=3)
    b=o.run_feedback(g,l,o.MODES[2],checkpoints=(0,30),horizon=5,trials=3)
    assert [(r['state'],r['action'],r['next_state']) for r in a['training_trace']]==[(r['state'],r['action'],r['next_state']) for r in b['training_trace']]
    assert o.json_hash(a['snapshots'][30])==o.json_hash(b['snapshots'][30])


def test_A_trajectory_matches_original_frozen_readout():
    g=line_game(3);l=record_right_path(g)
    r=o.run_feedback(g,l,o.MODES[0],checkpoints=(0,20),horizon=100,trials=10)
    ev=o.evaluate_snapshot(g,l,trials=10,horizon=100)
    assert [x['action'] for x in r['training_trace']]==[a for tr in ev['replays'] for a in tr['actions']]
    assert r['rows'][-1]['field_rebuilds']==1


@pytest.mark.parametrize('seed',range(79020000,79020008))
def test_saved_initial_snapshots_roundtrip(seed):
    g,l=o.load_case(seed)
    assert sum(l.action_visits.values())==2500
    assert o.json_hash(o.learner_data(l))==o.json_hash(json.loads((o.ROOT/'inputs'/str(seed)/'learner.json').read_text()))

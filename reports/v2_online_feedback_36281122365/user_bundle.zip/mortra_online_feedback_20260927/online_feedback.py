"""Development comparison: frozen / record+replan / record+replan+explore.

Existing V2 game, recorder, K builder and solver are loaded from fixed source.
The greedy readout is extracted from V2's evaluate_game AST. Only C's existing
fallback invokes the existing TaskBlindSelector. No Designer or oracle is used.
"""
from __future__ import annotations
import ast, copy, gzip, hashlib, importlib.util, inspect, json, sys, time
from pathlib import Path
from typing import Any
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
from experiments.task_agent.pretraining import TaskBlindSelector

V2_FILE = ROOT/'reference/v2_source_excerpt.py'
_spec = importlib.util.spec_from_file_location('v2_frozen_excerpt', V2_FILE)
v2 = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = v2
_spec.loader.exec_module(v2)
MODES = ('A_frozen','B_record_replan','C_record_replan_explore')


def dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=_json_default)+'\n')


def _json_default(x):
    if hasattr(x,'item'): return x.item()
    raise TypeError(type(x).__name__)


def json_hash(x):
    return hashlib.sha256(json.dumps(x,ensure_ascii=False,separators=(',',':'),sort_keys=True,allow_nan=False,default=_json_default).encode()).hexdigest()


def learner_data(learner):
    return {'id_to_state':learner.id_to_state,'state_to_id':list(learner.state_to_id.items()),
            'node_visits':list(learner.node_visits.items()),'action_visits':list(learner.action_visits.items()),
            'counts':[[k,list(v.items())] for k,v in learner.counts.items()],
            'dest_map':list(learner.dest_map.items())}


def restore_learner(d):
    learner=v2.StructuralLearner(num_actions=v2.NUM_ACTIONS)
    learner.id_to_state=[tuple(s) for s in d['id_to_state']]
    learner.state_to_id={tuple(s):int(u) for s,u in d['state_to_id']}
    learner.node_visits={int(u):int(n) for u,n in d['node_visits']}
    learner.action_visits={tuple(k):int(n) for k,n in d['action_visits']}
    learner.counts={tuple(k):{int(v):int(n) for v,n in items} for k,items in d['counts']}
    learner.dest_map={tuple(k):int(v) for k,v in d['dest_map']}
    assert {s:u for u,s in enumerate(learner.id_to_state)} == learner.state_to_id
    assert json_hash(learner_data(learner)) == json_hash(d)
    return learner


def restore_game(d):
    game=v2.MicroGame(width=d['width'],height=d['height'])
    for k in ['walls','hazards']: setattr(game,k,{tuple(x) for x in d[k]})
    for k in ['start_pos','goal_pos','key_pos','door_pos','switch_pos','gate_pos','block_pos','teleport_a','teleport_b']:
        setattr(game,k,tuple(d[k]) if d[k] is not None else None)
    game.rules=copy.deepcopy(d['rules'])
    assert json_hash(game.to_dict())==json_hash(d)
    return game


def load_case(seed):
    d=ROOT/'inputs'/str(seed)
    return (restore_game(json.loads((d/'game.json').read_text())),
            restore_learner(json.loads((d/'learner.json').read_text())))


def _compile_function(name,args,body):
    fn=ast.FunctionDef(name=name,args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=a) for a in args],
                           kwonlyargs=[],kw_defaults=[],defaults=[]),body=body,decorator_list=[])
    tree=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]))
    ns=dict(vars(v2))
    exec(compile(tree,'<v2-ast-adapter>','exec'),ns)
    return ns[name],ast.unparse(tree)


def _make_adapters():
    fn=ast.parse(inspect.getsource(v2.evaluate_game)).body[0]
    trial_loop=next(n for n in fn.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='trial')
    step_loop=next(n for n in trial_loop.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='step_i')
    start=next(i for i,n in enumerate(step_loop.body) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='u')
    end=next(i for i,n in enumerate(step_loop.body) if isinstance(n,ast.AugAssign) and ast.unparse(n.target)=='action_counts[best_a]')
    selection=copy.deepcopy(step_loop.body[start:end])
    assert ast.unparse(selection[-1].test)=='best_a is None or best_val <= 1e-08'
    original_selection=ast.dump(ast.Module(body=copy.deepcopy(selection),type_ignores=[]),include_attributes=False)
    selection.insert(-1,ast.Assign(targets=[ast.Name(id='fallback',ctx=ast.Store())],value=copy.deepcopy(selection[-1].test)))
    selection.append(ast.parse('return int(best_a), bool(fallback), float(best_val)').body[0])
    choose,choice_source=_compile_function('legacy_choose', ['learner','st','psi','trial'],selection)
    # Exact original K/field computation and self-play loops, with the initial
    # training prefix omitted and a logging append after each completed trial.
    begin=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='K')
    end2=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='random_result')
    body=copy.deepcopy(fn.body[begin:end2])
    loop_index=next(i for i,n in enumerate(body) if isinstance(n,ast.For) and ast.unparse(n.target)=='trial')
    body.insert(loop_index,ast.parse('all_trials = []').body[0])
    loop=body[loop_index+1]
    loop.body.extend(ast.parse("all_trials.append({'trial': trial, 'actions': recorded_actions, 'states': recorded_states, 'reached_goal': bool(reached)})").body)
    body.extend(ast.parse("return {'successes': mortra_successes, 'trials': self_play_trials, 'replays': all_trials, 'trial0': mortra_replay}").body)
    freeze,freeze_source=_compile_function('legacy_frozen_from_snapshot',['game','learner','self_play_trials','max_play_steps'],body)
    return choose,freeze,{'selection_ast_sha256':hashlib.sha256(original_selection.encode()).hexdigest(),
                          'choice_source':choice_source,'frozen_evaluation_source':freeze_source}

legacy_choose, legacy_frozen_from_snapshot, ADAPTERS = _make_adapters()


class ExperiencePort:
    """An observation/action-only capability. step cannot query another state.
    Public is_goal is legal during task execution, not an oracle distance.
    """
    __slots__=('_game','_state','steps','resets')
    def __init__(self,game):
        self._game=game
        self._state=None
        self.steps=0
        self.resets=0
    def reset(self):
        self._state=self._game.get_initial_state(); self.resets+=1
        return self._state
    def step(self,action):
        if self._state is None: raise RuntimeError('reset required')
        self._state=self._game.step(self._state,int(action));self.steps+=1
        return self._state
    def is_goal(self):return self._game.is_goal(self._state)


def compute_field(learner,goal_nodes):
    # The original V2 K builder and solver are used verbatim; no sparse
    # replacement and no shortest-path substitute for the goal field.
    K=learner.build_k_support()
    if goal_nodes:
        psi,it,res,conv=v2.solve_fixed_field(K,sorted(goal_nodes),q=0.90)
        return psi,{'iterations':int(it),'residual':float(res),'converged':bool(conv)}
    return np.zeros(len(learner.id_to_state)),{'iterations':0,'residual':None,'converged':None}


def evaluate_snapshot(game,learner,trials=50,horizon=100):
    if trials<1 or horizon<0: raise ValueError('invalid evaluation budget')
    before=json_hash(learner_data(learner)); g_before=json_hash(game.to_dict())
    frozen=copy.deepcopy(learner)
    result=legacy_frozen_from_snapshot(game.copy(),frozen,trials,horizon)
    assert json_hash(learner_data(frozen))==before
    assert json_hash(learner_data(learner))==before
    assert json_hash(game.to_dict())==g_before
    costs=[len(r['actions']) if r['reached_goal'] else horizon for r in result['replays']]
    assert sum(r['reached_goal'] for r in result['replays'])==result['successes']
    result.update(capped_costs=costs,mean_capped_steps=float(np.mean(costs)),
                  actual_actions=sum(len(r['actions']) for r in result['replays']),
                  snapshot_unchanged=True,snapshot_sha256=before)
    return result


def run_feedback(game,initial_learner,mode,checkpoints=(0,1000,5000),horizon=100,trials=50,
                 output: Path | None = None):
    if mode not in MODES: raise ValueError(mode)
    if tuple(sorted(set(checkpoints)))!=tuple(checkpoints) or not checkpoints or checkpoints[0]!=0 or checkpoints[-1]<0:
        raise ValueError('checkpoints must be unique, sorted and start at zero')
    if horizon<1 or trials<1:raise ValueError('invalid trial configuration')
    learner=copy.deepcopy(initial_learner)
    initial_hash=json_hash(learner_data(initial_learner)); game_hash=json_hash(game.to_dict())
    if checkpoints[-1]>0 and game.is_goal(game.get_initial_state()):
        raise ValueError('initial state is terminal; cannot meet positive exact action budget')
    selector=TaskBlindSelector('virtual_frontier') if mode==MODES[2] else None
    goal_nodes={u for u,s in enumerate(learner.id_to_state) if game.is_goal(s)}
    field_cpu=0.0;solver_events=[]
    def solve_at(step):
        nonlocal field_cpu
        t=time.process_time(); ans,detail=compute_field(learner,goal_nodes); field_cpu+=time.process_time()-t
        solver_events.append({'after_action':step,'known_states':len(learner.id_to_state),
                             'known_pairs':len(learner.counts),'goals':len(goal_nodes),**detail})
        return ans
    psi=solve_at(0)
    trace=[];snapshots={}; rows=[];evals={};rollouts=[]
    first_goal=0 if goal_nodes else None
    first_success=None; fallback_calls=selector_calls=0
    train_cpu=train_wall=0.0;eval_cpu=eval_wall=0.0
    port=ExperiencePort(game.copy())
    state=port.reset();trial=0;rollout_steps=0;rollout_start=1;reset_pending=False
    def checkpoint(step):
        nonlocal eval_cpu,eval_wall
        assert json_hash(game.to_dict())==game_hash
        assert json_hash(learner_data(initial_learner))==initial_hash
        snap=copy.deepcopy(learner_data(learner));snapshots[step]=snap
        t,w=time.process_time(),time.perf_counter()
        ev=evaluate_snapshot(game,learner,trials,horizon)
        eval_cpu+=time.process_time()-t;eval_wall+=time.perf_counter()-w
        evals[step]=ev
        row={'condition':mode,'additional_actions':step,'successes':ev['successes'],'trials':trials,
             'mean_capped_steps':ev['mean_capped_steps'],'evaluation_actual_actions':ev['actual_actions'],
             'known_states':len(learner.id_to_state),'known_pairs':len(learner.counts),
             'known_goal_states':len(goal_nodes),'recorded_visits':sum(learner.action_visits.values()),
             'first_goal_observation_action':first_goal,'first_training_success_action':first_success,
             'fallback_calls':fallback_calls,'selector_calls':selector_calls,
             'field_rebuilds':len(solver_events),'field_cpu_seconds':field_cpu,
             'completed_training_rollouts':len(rollouts),'training_successes':sum(r['success'] for r in rollouts),
             'reset_calls':port.resets,'train_cpu_seconds':train_cpu,'train_wall_seconds':train_wall,
             'evaluation_cpu_cumulative':eval_cpu,'evaluation_wall_cumulative':eval_wall,
             'snapshot_sha256':json_hash(snap),'game_sha256':game_hash,'snapshot_unchanged':ev['snapshot_unchanged']}
        rows.append(row)
        if output:
            dump(output/f'snapshot_{step}.json',snap)
            dump(output/f'evaluation_{step}.json',ev)
            dump(output/'partial_rows.json',rows)
        return row
    checkpoint(0)
    timer,w_timer=time.process_time(),time.perf_counter()
    for k in range(1,checkpoints[-1]+1):
        if reset_pending:
            state=port.reset();trial+=1;rollout_steps=0;rollout_start=k;reset_pending=False
        if mode!=MODES[0] and state not in learner.state_to_id:
            learner.get_or_add_id(state);psi=solve_at(k-1)
        action,fallback,best_value=legacy_choose(learner,state,psi,trial)
        fallback_calls+=int(fallback)
        telemetry={}
        if mode==MODES[2] and fallback:
            decision,telemetry=selector.choose(learner,state)
            action=int(decision.action);selector_calls+=1
        nxt=port.step(action);rollout_steps+=1
        hit=bool(port.is_goal())
        new_pair=new_state=changed=False
        if mode!=MODES[0]:
            u=learner.get_or_add_id(state)
            old_n=len(learner.id_to_state);old_v=learner.dest_map.get((u,action))
            new_pair=(u,action) not in learner.counts
            v=learner.get_or_add_id(nxt);new_state=len(learner.id_to_state)!=old_n
            learner.record_transition(u,action,v)
            new_goal=hit and v not in goal_nodes
            if hit:goal_nodes.add(v)
            if new_goal and first_goal is None:first_goal=k
            changed=new_pair or new_state or old_v!=v or new_goal
            if changed:psi=solve_at(k)
        if hit and first_success is None:first_success=k
        row={'additional_action':k,'trial':trial,'step_in_trial':rollout_steps,
             'state':state,'action':action,'next_state':nxt,'success':hit,'fallback':fallback,
             'selector_called':mode==MODES[2] and fallback,'legacy_best_value':best_value,
             'new_pair':bool(new_pair),'new_state':bool(new_state),'replanned':bool(changed),
             'known_states':len(learner.id_to_state),'known_pairs':len(learner.counts),
             'telemetry':telemetry}
        trace.append(row);state=nxt
        if hit or rollout_steps==horizon:
            rollouts.append({'trial':trial,'start_action':rollout_start,'end_action':k,'actions':rollout_steps,'success':hit})
            reset_pending=True
        if k in checkpoints:
            train_cpu+=time.process_time()-timer;train_wall+=time.perf_counter()-w_timer
            checkpoint(k)
            timer,w_timer=time.process_time(),time.perf_counter()
    assert port.steps==checkpoints[-1]
    assert json_hash(game.to_dict())==game_hash
    assert json_hash(learner_data(initial_learner))==initial_hash
    if mode==MODES[0]:assert json_hash(learner_data(learner))==initial_hash
    else:assert sum(learner.action_visits.values())==sum(initial_learner.action_visits.values())+checkpoints[-1]
    result={'condition':mode,'rows':rows,'training_trace':trace,'solver_events':solver_events,
            'training_rollouts':rollouts,'evaluations':evals,'snapshots':snapshots,
            'initial_snapshot_sha256':initial_hash,'game_sha256':game_hash,
            'exact_additional_actions':port.steps,'incomplete_final_rollout':None if reset_pending else
            {'trial':trial,'actions':rollout_steps,'success':False}}
    if output:
        with gzip.open(output/'training_trace.jsonl.gz','wt',encoding='utf8') as f:
            for row in trace:f.write(json.dumps(row,default=_json_default,allow_nan=False)+'\n')
        dump(output/'solver_events.json',solver_events);dump(output/'training_rollouts.json',rollouts)
        dump(output/'summary.json',{k:v for k,v in result.items() if k not in ('training_trace','solver_events','training_rollouts','evaluations','snapshots')})
    return result

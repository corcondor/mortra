# MORTRA V2: 自己プレイ経験を学習へ戻す小規模実験

## 実行した範囲

保存済み8 seed（79020000–79020007）の **初期ゲーム** と、そのゲームを
virtual-frontierで2500操作探索した保存モデルを使用。20反復後の最終ゲームではない。
3条件 × 追加0/1000/5000操作の3 checkpoint × 各50凍結評価試行。
独立単位は8 seed。学習操作は計120,000、凍結評価は計3,600試行。

これは失敗例を見て計画した開発実験であり、新規holdout確認ではない。
ゲーム・ゴール・規則は一切変更せず、Designerは実行していない。

## 結果

全条件で正確に追加5000操作を実行。リセットは操作由来の遷移に含めない。
学習中の成功は、下記の凍結評価成功とは別に記録している。

| 条件 | 追加0の成功 | 追加1000後の成功 | 追加5000後の成功 | 5000後の平均費用 |
|---|---:|---:|---:|---:|
| A: 既存凍結自己プレイ、更新なし |300/400|300/400|300/400|34.250|
| B: 同じreadout/fallback + 記録・再計画 |300/400|300/400|300/400|34.250|
| C: B + 未攻略時に既存virtual-frontier |300/400|400/400|400/400|12.125|

費用は成功時の実操作数、失敗時100。初期学習と追加学習の操作数はこの平均に含まない。
したがって「成功したゲームの経路が64.6%短縮された」とは言えない。
費用差-22.125は、2つの未攻略初期ゲームが攻略できるようになったことによる。
残り6 seedの凍結行動・成功・手数は不変。C-B/C-Aは改善2、悪化0、同値6 seed。

| seed | 初期既知状態/試行済pair | Cの初回goal観測（追加操作） | Cの5000後状態/pair | 凍結評価の手数 |
|---|---:|---:|---:|---:|
|79020003|2 / 6|283|53 / 189|全50試行15手|
|79020004|448 / 1716|396|536 / 2052|全50試行8手|

79020004のgoalは(10,10)のまま。ランダム変更がgoalを動かした過去結果とは異なる。
79020003は今回の初期ゲームでは未攻略だったが、過去の最終ゲームの成績とは混ぜていない。
探索器はこの2 seedで計679回呼ばれ、以後は既存のgoal-field readoutで成功する。
1000から5000操作で評価結果の上積みはなかった。途中で予算を打ち切ってはいない。

## 変更内容

- V2のゲーム、StructuralLearner、build_k_support、solve_fixed_fieldは指定ソースを使用。
- V2のevaluate_game内readoutをASTで抽出し、同点処理とfallback条件を保存。
- B/Cだけ、実際に実行したtransitionを既存record_transitionへ戻す。
- Kの構造または観測済みgoal集合が変わったときに同じV2 solverで再計算。
- Cだけ、旧fallback条件 `best_a is None or best_val <= 1e-8` に入ったときに
  `TaskBlindSelector('virtual_frontier')` を呼ぶ。source=1、q=.90、探索器は変更なし。
- 各rolloutは成功または100操作でreset。checkpoint評価で学習rolloutをresetしない。
- 各checkpointの評価は、学習器の独立コピーを凍結して旧readoutで実行。
- random評価の成功trajectoryは学習器へ渡さない。oracle、NN、source予測器は未使用。

## 再現・監査

- 元の8 artifactのSHA-256・CRC検査を通過。
- 保存された初期学習の全transitionから8モデルを再構築し、順序を含めて一致。
- 旧凍結自己プレイ400試行の全行動・全状態・成否を完全再現。
- 新規33テスト + 既存task-agent 9テスト = 42/42合格、実行前後とも。
- 全120,000学習操作を再生し、その時点のモデルから行動も再計算して一致。
- 全72 checkpointモデル・全3,600評価試行を再実行して保存値と一致。
- 評価中の105,600操作も再生確認。reset由来の架空edgeなし。
- 元ゲーム、入力モデル、凍結評価モデルの不変性を検査。
- 方策ソースは実験前後で不変。結果による方策調整、seed除外、失敗試行の交換なし。

検査の詳細は results/reproduction_gate.json、results/postrun_audit.json、
results/tests_before.xml、results/tests_after.xml を参照。

## コードの正本とローカル読み込み範囲

正本commit: `5f8b36744a29327928c87d6db888f2f045dbea79`
元run: `36273640831`。

`reference/v2_source_excerpt.py` は、GitHubで取得したV2の
MicroGame / StructuralLearner / solve_fixed_field / evaluate_random_player /
evaluate_game の定義を収録した抜粋。全スクリプトのバイト一致コピーではない。
CLI・描画・Designerの実行部分は含めず、ここで新たにゲーム規則を書き直していない。
`reference/extracted_adapters.json` に、抽出した旧readoutと凍結評価のコードを保存。
実際に呼ばれる全行動は前述の400試行再現および全trace監査で照合した。

探索器の `pretraining/core/exploration/virtual_frontier/online/__init__` の6ファイルは
元artifactに記録された正本SHA-256とLF正規化後に一致。
参照: reference/task_agent_source_verification.json。

自足実行用の `reference_loader.py` と `vendor/experiments/game_frontier_v1/frozen.py`
は、先のpretrainingパッケージ由来のimport補助。正規リポジトリへ上書きしてはならない。
本実験の学習器はV2のStructuralLearnerであり、import補助内の別learnerではない。
未使用のworld参照は同梱されているが、oracle関数を読み込む・実行する経路はない。

この実行はローカルLinux上。正規checkout全体での統合実行はまだしていない。
正規checkoutとの抜粋AST照合用に verify_checkout.py を同梱した。
このAST照合自体はローカルに完全checkoutがないため未実行であり、合格とは主張しない。

## 再現手順

実行環境: Python 3.13.5 / NumPy 2.3.5 / SciPy 1.17.0 / pytest 9.0.2。
OPENBLAS_NUM_THREADS=1、OMP_NUM_THREADS=1、MKL_NUM_THREADS=1。
Linux runnerを使用（run_seed.pyのRSS計測はresourceを使用）。

```sh
python -m pip install -r requirements-tested.txt
python reproduce.py --output ../mortra_online_feedback_rerun
```

入力とコードを新しいフォルダへ複製して実行する。既存出力の上書きは拒否する。
追加5,000操作/条件は同じ。スモールテストの成功後に予算を増減していない。
時間列を除き、同梱の72 snapshotと72凍結評価JSONを照合する。

正規checkout上の関数照合:

```sh
python verify_checkout.py /path/to/pinned/mortra
```

出力CSV:
- `results/all_checkpoints.csv`: 8 seed×3条件×3checkpoint =72行。
- `results/all_frozen_trials.csv`: 3,600試行の成否・操作数。
- `results/<seed>/<condition>/`: 全追加学習trace、field再計算記録、3モデル、3評価。

## 計算費用

追加学習区間CPUの8 seed合計はA約0.167秒、B約0.265秒、C約1.380秒。
これはこのローカル環境の参考計測で、solver初期化・凍結評価・JSON保存などを除く。
別途、各runの全経過時間とprocess RSSを保存。CPU削減の優位性は主張しない。

## 結論の範囲

同じゲームで、実際の行動経験を使って未攻略時の探索を継続し、その学習済みモデルから
攻略できることを確認した。単に旧行動の結果を記録するだけではこの2例は解消しなかった。

virtual-frontier固有の優位性は、このA/B/C比較だけでは示せない。
別の探索器との比較、8 seed外への一般化、制作ループ全体の完成度改善、数学・視覚への
転移、手動で定義された批評/変更規則の自律獲得は今回の実験範囲外。

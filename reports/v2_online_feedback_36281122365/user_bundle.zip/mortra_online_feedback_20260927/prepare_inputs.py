"""Extract pinned inputs only. Never run any policy or regenerate any game."""
from pathlib import Path
import hashlib, json, zipfile
ROOT=Path(__file__).resolve().parent
ARTIFACTS={
79020000:(10917235783,'5e05d8ec3cca309b130937db53a09f3ca400b0a020684fe1aa21b925af63eab0'),
79020001:(10917335540,'a20b5397c7bd7057357936c96fb0965f4230b4e7f9025ef6a80c8c248dd4682b'),
79020002:(10917286633,'dc48c0aaf46db70c62512d04ba45d98090ea7ea2f627d2ef82c6e8b4790e1849'),
79020003:(10916692120,'abb28debf5c7a5fa61f43a8199a8e6b56a40f0eaac935de8036e7601a2a27ba9'),
79020004:(10917048485,'326e01cad269f56b84b6e075a47c3e87fa3068cac73a27f2d9098b5aa9ba30ea'),
79020005:(10917477475,'28d89932d2cc8cc0835971764757fdeed69eea0bdba56565c4bf8f12da378b3f'),
79020006:(10917383104,'abdb99930e81b0f14d3272d5d4df4bd2c6ccb768b8ea97c4eff9c69a90510af4'),
79020007:(10916768390,'5dcb23e2ac62a4e68490dc56e62e3bf32d1603f660e624e3c96545e550d86e7f')}

def main():
 manifest=[]
 for seed,(aid,digest) in ARTIFACTS.items():
  path=ROOT.parent/(f'v2_original_{seed}_virtual.zip' if seed!=79020004 else 'v2_failure_79020004_virtual_original.zip')
  assert hashlib.sha256(path.read_bytes()).hexdigest()==digest, (seed,'archive digest')
  row={'seed':seed,'artifact_id':aid,'artifact_sha256':digest,'files':{}}
  out=ROOT/'inputs'/str(seed);out.mkdir(exist_ok=True)
  with zipfile.ZipFile(path) as z:
   assert z.testzip() is None
   prefix=f'v2_full_{seed}_virtual_frontier/targeted/evaluations/evaluation_000/'
   for name in ['game.json','learner.json','metrics.json','actions.jsonl.gz','training.jsonl.gz','audit.json']:
    content=z.read(prefix+name);(out/name).write_bytes(content)
    row['files'][name]=hashlib.sha256(content).hexdigest()
   source=z.read(f'v2_full_{seed}_virtual_frontier/source_snapshot.json')
   (out/'source_snapshot.json').write_bytes(source)
  manifest.append(row)
 (ROOT/'inputs/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Original ZIP hashes and CRC passed for',len(manifest),'seeds; initial snapshots only.')
 print(json.loads((ROOT/'inputs/79020004/source_snapshot.json').read_text()).keys())

if __name__=='__main__':main()

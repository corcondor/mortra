"""Replay all recorded interactions and independently rebuild every checkpoint.
This read-only audit runs after outcomes. It never changes a policy or game.
"""
import copy, csv, gzip, hashlib, json, time
from pathlib import Path
from collections import defaultdict
import online_feedback as o
from run_seed import verify_sources


def main():
    verify_sources(); began=time.perf_counter()
    totals={'learning_actions_replayed':0,'frozen_evaluation_actions_replayed':0,
            'frozen_trials':0,'snapshots_verified':0,'policy_actions_recomputed':0,
            'virtual_selector_calls_recomputed':0,'games':0}
    out_rows=[];cases=[];pair_rows=[]
    for seed in range(79020000,79020008):
        game,start=o.load_case(seed); gh=o.json_hash(game.to_dict())
        done=json.loads((o.ROOT/'results'/str(seed)/'completed.json').read_text())
        assert done['status']=='COMPLETE_DEVELOPMENT_COMPARISON'
        out_rows.extend(done['rows']);totals['games']+=1
        for mode in o.MODES:
            d=o.ROOT/'results'/str(seed)/mode
            with gzip.open(d/'training_trace.jsonl.gz','rt') as f: trace=[json.loads(x) for x in f]
            assert len(trace)==5000
            model=copy.deepcopy(start)
            selector=o.TaskBlindSelector('virtual_frontier') if mode==o.MODES[2] else None
            goals={u for u,s in enumerate(model.id_to_state) if game.is_goal(s)}
            psi,_=o.compute_field(model,goals)
            state=game.get_initial_state();trial=0;step_in_trial=0;pending=False
            first_goal=0 if goals else None;selector_count=0;rebuilds=1
            checkpoint_models={0:copy.deepcopy(model)}
            for k,row in enumerate(trace,1):
                if pending:state=game.get_initial_state();trial+=1;step_in_trial=0;pending=False
                assert row['trial']==trial and row['additional_action']==k and row['step_in_trial']==step_in_trial+1
                assert tuple(row['state'])==state
                if mode!=o.MODES[0] and state not in model.state_to_id:
                    model.get_or_add_id(state);psi,_=o.compute_field(model,goals);rebuilds+=1
                action,fallback,best_value=o.legacy_choose(model,state,psi,trial)
                assert row['fallback']==fallback
                assert row['selector_called']==(mode==o.MODES[2] and fallback)
                if mode==o.MODES[2] and fallback:
                    before=o.json_hash(o.learner_data(model))
                    dec,telemetry=selector.choose(model,state)
                    assert o.json_hash(o.learner_data(model))==before
                    action=int(dec.action);selector_count+=1
                    assert telemetry['generic_scores']=={int(a):v for a,v in row['telemetry']['generic_scores'].items()}
                    if telemetry['source_min'] is not None:assert telemetry['source_min']==telemetry['source_max']==1
                    totals['virtual_selector_calls_recomputed']+=1
                assert row['action']==action,(seed,mode,k,'policy')
                assert best_value==row['legacy_best_value']
                totals['policy_actions_recomputed']+=1
                nxt=game.step(state,action);assert tuple(row['next_state'])==nxt
                hit=game.is_goal(nxt);assert hit==row['success']
                if mode!=o.MODES[0]:
                    u=model.get_or_add_id(state);old_count=len(model.id_to_state);old_dest=model.dest_map.get((u,action))
                    new_pair=(u,action) not in model.counts
                    v=model.get_or_add_id(nxt);new_state=len(model.id_to_state)!=old_count
                    model.record_transition(u,action,v)
                    new_goal=hit and v not in goals
                    if hit:goals.add(v)
                    if new_goal and first_goal is None:first_goal=k
                    rebuild=bool(new_pair or new_state or old_dest!=v or new_goal)
                    assert rebuild==row['replanned'] and new_pair==row['new_pair'] and new_state==row['new_state']
                    if rebuild:psi,_=o.compute_field(model,goals);rebuilds+=1
                assert len(model.id_to_state)==row['known_states'] and len(model.counts)==row['known_pairs']
                state=nxt;step_in_trial+=1;pending=hit or step_in_trial==100
                totals['learning_actions_replayed']+=1
                if k in (1000,5000):checkpoint_models[k]=copy.deepcopy(model)
            for checkpoint,l in checkpoint_models.items():
                stored=json.loads((d/f'snapshot_{checkpoint}.json').read_text())
                assert o.json_hash(stored)==o.json_hash(o.learner_data(l)),(seed,mode,checkpoint,'snapshot')
                totals['snapshots_verified']+=1
                ev=json.loads((d/f'evaluation_{checkpoint}.json').read_text())
                before=o.json_hash(o.learner_data(l))
                rerun=o.evaluate_snapshot(game,l)
                assert o.json_hash(rerun)==o.json_hash(ev),(seed,mode,checkpoint,'frozen evaluation')
                assert o.json_hash(o.learner_data(l))==before
                for rep in ev['replays']:
                    s=game.get_initial_state(); assert tuple(rep['states'][0])==s
                    for a,t in zip(rep['actions'],rep['states'][1:],strict=True):
                        s=game.step(s,a);assert tuple(t)==s;totals['frozen_evaluation_actions_replayed']+=1
                    assert game.is_goal(s)==rep['reached_goal']
                    totals['frozen_trials']+=1
                    pair_rows.append({'seed':seed,'condition':mode,'additional_actions':checkpoint,'trial':rep['trial'],
                                      'success':rep['reached_goal'],'actions':len(rep['actions']),
                                      'capped_steps':len(rep['actions']) if rep['reached_goal'] else 100})
            assert o.json_hash(game.to_dict())==gh
            cases.append({'seed':seed,'condition':mode,'training_actions':len(trace),'snapshots':3,
                          'frozen_trials':150,'first_goal_observation':first_goal,'rebuilds':rebuilds,
                          'selector_calls':selector_count,'status':'PASS'})
        print('Audit PASS',seed,flush=True)
    assert totals['learning_actions_replayed']==120000 and totals['snapshots_verified']==72 and totals['frozen_trials']==3600
    verify_sources()
    audit={'status':'PASS','totals':totals,'cases':cases,'seconds':time.perf_counter()-began,
           'source_unchanged':True,'discrete_mismatches':0,
           'note':'Full replay audit; original 8 games and goals fixed; no reset transition fabricated; evaluation copies never update learner.'}
    o.dump(o.ROOT/'results/postrun_audit.json',audit)
    for name,rs in [('all_checkpoints.csv',out_rows),('all_frozen_trials.csv',pair_rows)]:
        with (o.ROOT/'results'/name).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
    groups=defaultdict(list)
    for r in out_rows:groups[(r['condition'],r['additional_actions'])].append(r)
    agg=[]
    for (mode,b),rs in sorted(groups.items()):
        assert len(rs)==8
        agg.append({'condition':mode,'additional_actions_per_seed':b,'seeds':8,
                    'successes':sum(r['successes'] for r in rs),'trials':sum(r['trials'] for r in rs),
                    'mean_capped_steps':sum(r['mean_capped_steps'] for r in rs)/8,
                    'selector_calls':sum(r['selector_calls'] for r in rs),'first_goals':{str(r['seed']):r['first_goal_observation_action'] for r in rs},
                    'train_cpu_seconds':sum(r['train_cpu_seconds'] for r in rs),
                    'eval_cpu_cumulative':sum(r['evaluation_cpu_cumulative'] for r in rs)})
    pairs=[]
    for b in (0,1000,5000):
        for left,right in [(o.MODES[1],o.MODES[0]),(o.MODES[2],o.MODES[1]),(o.MODES[2],o.MODES[0])]:
            a={r['seed']:r for r in groups[left,b]};bb={r['seed']:r for r in groups[right,b]}
            ds=[a[s]['mean_capped_steps']-bb[s]['mean_capped_steps'] for s in sorted(a)]
            pairs.append({'additional_actions':b,'left':left,'right':right,'world_differences':ds,
                          'mean_difference':sum(ds)/8,'improved_seeds':sum(d<0 for d in ds),
                          'worse_seeds':sum(d>0 for d in ds),'tied_seeds':sum(d==0 for d in ds)})
    summary={'status':'COMPLETE_DEVELOPMENT_COMPARISON','seeds':8,'conditions':3,'checkpoints':[0,1000,5000],
             'additional_learning_actions':120000,'frozen_evaluation_trials':3600,'aggregates':agg,
             'paired_seed_comparisons':pairs,'source_unchanged':True,
             'scope':'historical fixed initial games; not final designed games; old trials are not independent games; no claim of VF superiority over every alternative explorer'}
    o.dump(o.ROOT/'results/summary.json',summary)
    print(json.dumps({'totals':totals,'aggregates':agg},indent=2))
if __name__=='__main__':main()

"""Select the self-contained vendored runtime; no remote repository is mutated."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))

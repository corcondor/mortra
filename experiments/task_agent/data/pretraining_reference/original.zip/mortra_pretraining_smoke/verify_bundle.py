from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
errors=[];count=0
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    expected,name=line.split('  ',1);path=ROOT/name;count+=1
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:errors.append(name)
print({'files_checked':count,'mismatches':errors})
if errors:raise SystemExit(1)

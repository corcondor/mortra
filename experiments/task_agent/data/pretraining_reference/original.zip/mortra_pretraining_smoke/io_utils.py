from pathlib import Path
import hashlib, json
import bootstrap
from experiments.game_frontier_v1.frozen import StructuralLearner

def save_json(path, value):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def encode(learner):
    # Preserve dictionary insertion order, including nested counts.
    return {'num_actions': learner.num_actions, 'states': [list(s) for s in learner.id_to_state],
            'state_to_id': [[list(s), v] for s,v in learner.state_to_id.items()],
            'node_visits': [[k,v] for k,v in learner.node_visits.items()],
            'action_visits': [[list(k),v] for k,v in learner.action_visits.items()],
            'counts': [[list(k), [[v,n] for v,n in d.items()]] for k,d in learner.counts.items()],
            'dest_map': [[list(k),v] for k,v in learner.dest_map.items()]}

def decode(d):
    learner=StructuralLearner(d['num_actions'])
    learner.id_to_state=[tuple(s) for s in d['states']]
    learner.state_to_id={tuple(s):v for s,v in d['state_to_id']}
    learner.node_visits=dict(d['node_visits'])
    learner.action_visits={tuple(k):v for k,v in d['action_visits']}
    learner.counts={tuple(k):dict(v) for k,v in d['counts']}
    learner.dest_map={tuple(k):v for k,v in d['dest_map']}
    return learner

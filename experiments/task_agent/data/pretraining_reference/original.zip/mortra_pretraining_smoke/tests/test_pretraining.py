import copy, inspect, json
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pytest
import bootstrap
from reference_loader import StructuralLearner,Engine
from io_utils import encode,decode,sha256
from experiments.task_agent.pretraining import SingletonMemory,TaskBlindSelector,train_snapshots_with_policy,METHODS
from experiments.task_agent.virtual_frontier import VirtualFrontierPolicy,build_frontier_fields
from experiments.task_agent.core import SequenceTask,AllTask,ExactState
ROOT=Path(__file__).resolve().parents[1]

class TinyWorld:
    initial=(0,)
    num_actions=2
    def __init__(self):self.calls=0
    def step(self,s,a):
        self.calls+=1
        return ((s[0]+1)%5,) if a==0 else (s[0],)


def test_six_full_files_byte_identical():
    data=json.loads((ROOT/'manifest_before.json').read_text())
    for path,detail in data['full_file_checks'].items():
        p=ROOT/'vendor'/path if path.startswith('experiments/task_agent/') else ROOT/'reference/world.py'
        assert sha256(p)==detail['expected']

@pytest.mark.parametrize('seed',range(73000000,73000008))
def test_structural_512_exact_saved_attributes_and_order(seed):
    p=ROOT/'inputs'/str(seed)
    engine=Engine(json.loads((p/'genome.json').read_text()))
    got=train_snapshots_with_policy(engine,'structural',(128,512)).snapshots[512]
    saved=json.loads((p/'snapshot_512.json').read_text())
    assert encode(got)==saved
    assert encode(decode(saved))==saved

@pytest.mark.parametrize('method',METHODS)
def test_exact_budget_private_checkpoints_and_determinism(method):
    world=TinyWorld();logs=[]
    out=train_snapshots_with_policy(world,method,(0,8,20),trace_sink=logs.append)
    assert world.calls==20 and len(logs)==20
    for b in (0,8,20):assert sum(out.snapshots[b].action_visits.values())==b
    first=copy.deepcopy(out.snapshots[8].__dict__)
    out.snapshots[20].counts.clear()
    assert out.snapshots[8].__dict__==first
    again=train_snapshots_with_policy(TinyWorld(),method,(8,))
    assert again.snapshots[8].__dict__==first

@pytest.mark.parametrize('budgets',[(),(-1,),(8,4),(4,4),(1.2,),(True,)])
def test_bad_budget_rejected(budgets):
    with pytest.raises(ValueError):train_snapshots_with_policy(TinyWorld(),'virtual_frontier',budgets)


def test_bad_method_rejected():
    with pytest.raises(ValueError):TaskBlindSelector('oracle')


def test_no_task_in_training_interface():
    assert 'task' not in inspect.signature(train_snapshots_with_policy).parameters
    class Poison:
        def __getattribute__(self,name):raise AssertionError('raw observation inspected')
    assert SingletonMemory.advance(123,Poison())==0
    with pytest.raises(AssertionError):SingletonMemory.progress(0)
    with pytest.raises(AssertionError):SingletonMemory.accepting(0)
    train_snapshots_with_policy(TinyWorld(),'virtual_frontier',(20,))


def test_training_only_observation_stream_no_oracle():
    world=TinyWorld()
    class Restricted:
        def __getattribute__(self,name):
            if name not in {'initial','num_actions','step'}:raise AssertionError(name)
            return getattr(world,name)
    train_snapshots_with_policy(Restricted(),'virtual_frontier',(12,))
    assert world.calls==12


def test_selector_only_learned_interface():
    learner=StructuralLearner(2)
    for s in ('S','L','R'):learner.get_or_add_id(s)
    learner.record_transition(0,0,1);learner.record_transition(0,1,2)
    allowed={'state_to_id','id_to_state','num_actions','counts','action_visits'}
    class Restricted:
        def __getattribute__(self,name):
            if name not in allowed:raise AssertionError(name)
            return getattr(learner,name)
    a,_=TaskBlindSelector('virtual_frontier').choose(Restricted(),'S')
    assert a.action==0


def test_singleton_graph_and_sources():
    learner=StructuralLearner(2)
    for s in ('S','L','R'):learner.get_or_add_id(s)
    learner.record_transition(0,0,1);learner.record_transition(0,1,2)
    fields=build_frontier_fields(learner,'S',SingletonMemory(),0,task_source=False)
    assert fields.states==[(0,0),(1,0),(2,0)]
    assert len(fields.virtual)==4
    assert np.array_equal(fields.sources[:3],np.zeros((3,2)))
    assert np.array_equal(fields.sources[3:],np.ones((4,2)))
    assert fields.kernel[3:].nnz==0
    assert np.array_equal(fields.values[:,0],fields.values[:,1])
    assert not fields.signal_available


def test_no_unknown_successor_lookup():
    learner=StructuralLearner(2);learner.get_or_add_id('S')
    class PoisonCounts(dict):
        def get(self,*args):raise AssertionError('unknown successor accessed')
    learner.counts=PoisonCounts()
    d,_=TaskBlindSelector('virtual_frontier').choose(learner,'S')
    assert d.action==0


def test_singleton_equals_generic_dummy_task():
    learner=StructuralLearner(2)
    for s in ('S','L','R'):learner.get_or_add_id(s)
    learner.record_transition(0,0,1);learner.record_transition(0,1,2)
    a,_=TaskBlindSelector('virtual_frontier').choose(learner,'S')
    for task in (SequenceTask([ExactState('unseen')]),AllTask([ExactState('unseen')])):
        b=VirtualFrontierPolicy(task_aware=False,task_source=False).choose(learner,'S',task,0)
        assert a.action==b.action and a.score==b.score


def test_no_frontier_local_fallback():
    learner=StructuralLearner(2);learner.get_or_add_id('S')
    learner.record_transition(0,0,0);learner.record_transition(0,1,0)
    d,info=TaskBlindSelector('virtual_frontier').choose(learner,'S')
    assert d.action==0 and not info['virtual_field_decision']

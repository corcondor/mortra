"""Load original definitions, skipping unused imports and script side effects.

The learner class is an exact source excerpt. world.py is a byte-identical
full file, but only validate/Engine definitions are executed; oracle is NOT loaded.
"""
import ast
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parent

def load_selected(path, names, namespace):
    tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names]
    if {n.name for n in nodes} != set(names):
        raise ValueError(f'missing definitions in {path}')
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace

_ns = load_selected(ROOT/'reference/structural_learner_excerpt.py', {'StructuralLearner'}, {'np': np})
StructuralLearner = _ns['StructuralLearner']
_ns = load_selected(ROOT/'reference/world.py', {'validate', 'Engine'}, {})
Engine = _ns['Engine']

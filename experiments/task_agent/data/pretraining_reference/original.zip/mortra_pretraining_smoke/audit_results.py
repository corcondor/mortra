"""Post-run read-only replay audit. No policy or source is optimized here."""
from pathlib import Path
import gzip,json,collections
import bootstrap
from io_utils import encode,save_json,sha256
from reference_loader import StructuralLearner,Engine
from experiments.task_agent.online_eval import task_from_spec
from run_smoke import SEEDS,BUDGETS,METHODS,assert_sealed
ROOT=Path(__file__).resolve().parent
assert_sealed()
old=json.loads((ROOT/'inputs/original_preflight.json').read_text())
original_test_hash=sha256(ROOT/'tests/test_task_agent.py')
assert original_test_hash==old['source_sha256']['tests/test_task_agent.py']
training_steps=eval_steps=checkpoint_matches=episode_matches=0
pair_details=[]
for seed in SEEDS:
    g=json.loads((ROOT/'inputs'/str(seed)/'genome.json').read_text())
    engine=Engine(g);out=ROOT/'results'/str(seed)
    learners={m:StructuralLearner(engine.num_actions) for m in METHODS}
    states={m:engine.initial for m in METHODS}
    for l in learners.values():l.get_or_add_id(engine.initial)
    counts=collections.Counter()
    with gzip.open(out/'training_trace.jsonl.gz','rt') as f:
        for line in f:
            x=json.loads(line);method=x['method'];l=learners[method]
            state=states[method]; counts[method]+=1
            assert tuple(x['state'])==state and x['step']==counts[method]
            assert l.get_or_add_id(state)==x['u']
            if method=='structural':assert l.select_action(x['u'])==x['action']
            nxt=engine.step(state,x['action']);assert nxt==tuple(x['next_state'])
            v=l.get_or_add_id(nxt);assert v==x['v']
            l.record_transition(x['u'],x['action'],v);states[method]=nxt
            training_steps+=1
            if x['step'] in BUDGETS:
                stored=json.loads((out/f'snapshot_{method}_{x["step"]}.json').read_text())
                assert encode(l)==stored
                checkpoint_matches+=1
    assert all(counts[m]==max(BUDGETS) for m in METHODS)
    tasks={x['task_id']:x for x in json.loads((ROOT/'inputs'/str(seed)/'tasks.json').read_text())}
    es={(r['method'],r['budget'],r['task_id']):r for r in json.loads((out/'episodes.json').read_text())}
    current={};memories={};sizes=collections.Counter()
    with gzip.open(out/'evaluation_trace.jsonl.gz','rt') as f:
        for line in f:
            x=json.loads(line);k=(x['method'],x['budget'],x['task_id']);entry=tasks[x['task_id']]
            task=task_from_spec(entry['spec'])
            state=current.get(k,tuple(entry['start']))
            memory=memories.get(k,task.advance(task.initial_memory,state))
            assert tuple(x['state'])==state and x['step']==sizes[k]+1
            nxt=engine.step(state,x['action']);assert nxt==tuple(x['next_state'])
            sizes[k]+=1;eval_steps+=1;current[k]=nxt;memories[k]=task.advance(memory,nxt)
    for k,row in es.items():
        assert sizes[k]==row['task_steps']
        task=task_from_spec(tasks[k[2]]['spec'])
        assert task.accepting(memories[k])==row['success']==row['final_memory_accepting']
        episode_matches+=1
    for b in BUDGETS:
        for task_id in tasks:
            s=es['structural',b,task_id];t=es['frontier_t0',b,task_id];v=es['virtual_frontier',b,task_id]
            pair_details.append({'seed':seed,'budget':b,'task_id':task_id,'task_type':tasks[task_id]['task_type'],
                'structural_steps':s['capped_steps'],'frontier_t0_steps':t['capped_steps'],'virtual_frontier_steps':v['capped_steps'],
                'virtual_minus_structural':v['capped_steps']-s['capped_steps'],
                'virtual_minus_frontier_t0':v['capped_steps']-t['capped_steps']})
from run_smoke import write_csv
write_csv(ROOT/'results/task_pairs.csv',pair_details)
worst=sorted(pair_details,key=lambda x:x['virtual_minus_structural'],reverse=True)
write_csv(ROOT/'results/virtual_vs_structural_all_cases.csv',worst)
save_json(ROOT/'results/postrun_audit.json',{'passed':True,'original_9_tests_byte_identical':True,
    'training_transitions_replayed':training_steps,'checkpoint_replay_matches':checkpoint_matches,
    'evaluation_transitions_replayed':eval_steps,'episodes_replayed':episode_matches,
    'terminal_memory_success_mismatches':0,'source_hashes_unchanged':True,
    'note':'Successful comparison attempt audited; interrupted world-7 attempt retained separately. No oracle graph or oracle distances computed.'})
print('AUDIT PASS',training_steps,'training transitions',eval_steps,'evaluation transitions',episode_matches,'episodes')

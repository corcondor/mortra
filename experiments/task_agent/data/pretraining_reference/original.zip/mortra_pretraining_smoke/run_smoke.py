"""Execute the fixed development protocol. See PROTOCOL.md for scope/limits."""
from __future__ import annotations
import argparse, copy, csv, json, time, gzip, sys, platform
from pathlib import Path
import bootstrap
from io_utils import encode, decode, save_json, sha256
from reference_loader import Engine
from experiments.task_agent.online import OnlineTaskAgent
from experiments.task_agent.online_eval import CachingSparsePlanner, WorldEnv, task_from_spec
from experiments.task_agent.virtual_frontier import VirtualFrontierPolicy
from experiments.task_agent.pretraining import train_snapshots_with_policy, METHODS
ROOT=Path(__file__).resolve().parent
SEEDS=tuple(range(73000000,73000008))
BUDGETS=(128,512,2048)
CAP=4096


def write_csv(path, rows):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def assert_sealed():
    sealed=json.loads((ROOT/'manifest_before.json').read_text())
    for path,expected in sealed['source_sha256'].items():
        if sha256(ROOT/path)!=expected:
            raise RuntimeError('source changed after sealing: '+path)
    if sha256(ROOT/'PROTOCOL.md')!=sealed['protocol_sha256']:
        raise RuntimeError('protocol changed')
    for entry in sealed['inputs']:
        if sha256(ROOT/entry['path'])!=entry['sha256']:
            raise RuntimeError('input changed: '+entry['path'])
    return sealed


class TracedEnv(WorldEnv):
    """Log only real execution; does not change the transition function."""
    def __init__(self,engine,sink,identity):
        super().__init__(engine); self.sink=sink;self.identity=identity; self.steps=0
    def step(self,action):
        before=self.state
        after=super().step(action);self.steps+=1
        if self.sink is not None:
            self.sink.write(json.dumps({**self.identity,'step':self.steps,'state':before,
                                       'action':int(action),'next_state':after})+'\n')
        return after


def evaluate(snapshot, engine, entry, *, sink=None, identity=None):
    """All arms use exactly the same frozen post-training algorithm."""
    before=encode(snapshot)
    learner=copy.deepcopy(snapshot)
    task=task_from_spec(entry['spec'])
    start=tuple(entry['start'])
    inspector=CachingSparsePlanner(q=0.90)
    model=inspector.build(learner,task,start,task.advance(task.initial_memory,start))
    starts_in_model=bool(model.states and 0 in model.reachable_to_accept)
    # Keep this separate from the executor's cache, so diagnosis changes no state.
    planner=CachingSparsePlanner(q=0.90)
    policy=VirtualFrontierPolicy(task_aware=False)
    agent=OnlineTaskAgent(learner,policy,planner=planner,max_task_steps=CAP,max_exploration_steps=CAP)
    env=TracedEnv(engine,sink,identity or {})
    cpu0,wall0=time.process_time(),time.perf_counter()
    result=agent.run_task(env,task,start)
    cpu,wall=time.process_time()-cpu0,time.perf_counter()-wall0
    assert env.steps==result.task_steps
    assert encode(snapshot)==before, 'evaluation mutated initial snapshot'
    row={'success':bool(result.success),'task_steps':result.task_steps,
         'capped_steps':result.task_steps if result.success else CAP,
         'exploration_steps':result.exploration_steps,'starts_in_model':starts_in_model,
         'initial_known_states':len(snapshot.id_to_state),'final_known_states':len(learner.id_to_state),
         'failure_reason':result.failure_reason,'final_memory_accepting':bool(task.accepting(result.final_memory)),
         'eval_cpu_seconds':cpu,'eval_wall_seconds':wall}
    return row


def reproduce():
    assert_sealed()
    path=ROOT/'results/reproduction.json'
    if path.exists(): raise FileExistsError(path)
    ref=json.loads((ROOT/'inputs/reference_episodes.json').read_text())
    reference={(int(r['seed']),int(r['task_id'])):r for r in ref}
    mismatches=[];snapshots=[];rows=[]
    for seed in SEEDS:
        root=ROOT/'inputs'/str(seed)
        engine=Engine(json.loads((root/'genome.json').read_text()))
        saved=json.loads((root/'snapshot_512.json').read_text())
        new=train_snapshots_with_policy(engine,'structural',(512,)).snapshots[512]
        equal=encode(new)==saved
        snapshots.append({'seed':seed,'all_attributes_and_insertion_order_equal':equal})
        if not equal:mismatches.append({'seed':seed,'kind':'snapshot'})
        for entry in json.loads((root/'tasks.json').read_text()):
            row=evaluate(new,engine,entry)
            old=reference[(seed,entry['task_id'])]
            same=(row['success']==(old['success']=='True') and
                  row['task_steps']==int(old['task_steps']) and
                  row['exploration_steps']==int(old['exploration_steps']))
            rows.append({'seed':seed,'task_id':entry['task_id'],'same':same,**row})
            if not same:mismatches.append({'seed':seed,'task_id':entry['task_id'],'kind':'episode','got':row,'reference':old})
        print('reproduced',seed,'snapshot=',equal,flush=True)
    result={'passed':not mismatches,'snapshots_compared':len(snapshots),
            'episodes_compared':len(rows),'snapshots':snapshots,'mismatches':mismatches,'rows':rows}
    save_json(path,result)
    if mismatches:raise RuntimeError(f'{len(mismatches)} reference mismatches; no comparison allowed')
    print('REPRODUCTION PASS',len(snapshots),'snapshots',len(rows),'episodes',flush=True)


def compare_world(seed):
    assert_sealed()
    if seed not in SEEDS:raise ValueError('seed outside sealed cohort')
    gate=json.loads((ROOT/'results/reproduction.json').read_text())
    if not gate['passed']:raise RuntimeError('reference gate not passed')
    out=ROOT/'results'/str(seed);out.mkdir(exist_ok=False)
    root=ROOT/'inputs'/str(seed)
    engine=Engine(json.loads((root/'genome.json').read_text()))
    tasks=json.loads((root/'tasks.json').read_text())
    assert len(tasks)==12
    all_rows=[];training_rows=[]
    try:
        with gzip.open(out/'training_trace.jsonl.gz','wt',encoding='utf-8') as train_sink, \
             gzip.open(out/'evaluation_trace.jsonl.gz','wt',encoding='utf-8') as eval_sink:
            for method in METHODS:
                def emit(row):
                    train_sink.write(json.dumps({'seed':seed,'method':method,**row})+'\n')
                trained=train_snapshots_with_policy(engine,method,BUDGETS,trace_sink=emit)
                for metric in trained.metrics:training_rows.append({'seed':seed,**metric})
                for budget in BUDGETS:
                    snapshot=trained.snapshots[budget]
                    save_json(out/f'snapshot_{method}_{budget}.json',encode(snapshot))
                    for entry in tasks:
                        ident={'seed':seed,'method':method,'budget':budget,'task_id':entry['task_id'],'task_type':entry['task_type']}
                        row=evaluate(snapshot,engine,entry,sink=eval_sink,identity=ident)
                        all_rows.append({**ident,**row})
                    print('completed',seed,method,budget,'mean=',round(sum(r['capped_steps'] for r in all_rows if r['method']==method and r['budget']==budget)/12,3),flush=True)
        assert len(all_rows)==108
        write_csv(out/'episodes.csv',all_rows);write_csv(out/'training.csv',training_rows)
        save_json(out/'episodes.json',all_rows);save_json(out/'training.json',training_rows)
        save_json(out/'status.json',{'status':'COMPLETE','episodes':len(all_rows)})
    except Exception as exc:
        save_json(out/'partial_episodes.json',all_rows)
        save_json(out/'status.json',{'status':'INCOMPLETE','exception':repr(exc)})
        raise


def summarize():
    manifest=assert_sealed()
    episodes=[];training=[]
    for seed in SEEDS:
        root=ROOT/'results'/str(seed)
        status=json.loads((root/'status.json').read_text())
        if status['status']!='COMPLETE':raise RuntimeError('incomplete world '+str(seed))
        episodes+=json.loads((root/'episodes.json').read_text())
        training+=json.loads((root/'training.json').read_text())
    keys={(r['seed'],r['method'],r['budget'],r['task_id']) for r in episodes}
    assert len(keys)==len(episodes)==864
    aggregates=[];worlds=[];pairs=[]
    for budget in BUDGETS:
        for method in METHODS:
            sub=[r for r in episodes if r['method']==method and r['budget']==budget]
            tr=[r for r in training if r['method']==method and r['budget']==budget]
            mean=sum(r['capped_steps'] for r in sub)/len(sub)
            aggregates.append({'budget':budget,'method':method,'episodes':len(sub),
                'successes':sum(r['success'] for r in sub),'mean_task_steps':mean,
                'amortized_steps_per_task_12':mean+budget/12,'single_task_with_pretraining_steps':mean+budget,
                'mean_batch_12_total_steps':budget+12*mean,
                'starts_in_model':sum(r['starts_in_model'] for r in sub),
                'mean_known_states':sum(r['known_states'] for r in tr)/len(tr),
                'mean_known_pairs':sum(r['known_pairs'] for r in tr)/len(tr),
                'train_cpu_seconds_all_worlds':sum(r['train_cpu_seconds_cumulative'] for r in tr),
                'eval_cpu_seconds_all_tasks':sum(r['eval_cpu_seconds'] for r in sub)})
            for seed in SEEDS:
                s=[r for r in sub if r['seed']==seed]
                worlds.append({'seed':seed,'budget':budget,'method':method,
                    'successes':sum(r['success'] for r in s),'mean_task_steps':sum(r['capped_steps'] for r in s)/12})
        base={r['seed']:r for r in worlds if r['budget']==budget and r['method']=='structural'}
        for method in ('frontier_t0','virtual_frontier'):
            diff=[r['mean_task_steps']-base[r['seed']]['mean_task_steps'] for r in worlds if r['budget']==budget and r['method']==method]
            taskdiff=[r['capped_steps']-next(b['capped_steps'] for b in episodes if b['seed']==r['seed'] and b['task_id']==r['task_id'] and b['budget']==budget and b['method']=='structural') for r in episodes if r['budget']==budget and r['method']==method]
            pairs.append({'budget':budget,'method_minus_structural':method,'world_mean_difference':sum(diff)/8,
                'worlds_improved':sum(x<0 for x in diff),'worlds_worse':sum(x>0 for x in diff),'worlds_tied':sum(x==0 for x in diff),
                'tasks_improved':sum(x<0 for x in taskdiff),'tasks_worse':sum(x>0 for x in taskdiff),'tasks_tied':sum(x==0 for x in taskdiff),
                'worst_task_regression':max(taskdiff)})
    mismatches=[r for r in episodes if r['success']!=r['final_memory_accepting']]
    summary={'status':'COMPLETE_DEVELOPMENT_SMOKE','worlds':8,'tasks':96,'comparison_episodes':864,
             'reference_reproduction_episodes':96,'reproduction_passed':True,
             'interpretation':'descriptive historical slice; no oracle, no learned-source model, no confirmatory generalization claim',
             'aggregates':aggregates,'paired_world_comparisons':pairs,
             'terminal_memory_success_mismatches':len(mismatches),
             'training_max_field_residual':max(r['max_field_residual'] for r in training),
             'source_manifest_sha256':sha256(ROOT/'manifest_before.json')}
    save_json(ROOT/'results/summary.json',summary)
    write_csv(ROOT/'results/aggregate.csv',aggregates)
    write_csv(ROOT/'results/world_means.csv',worlds)
    write_csv(ROOT/'results/paired_world_comparisons.csv',pairs)
    write_csv(ROOT/'results/all_episodes.csv',episodes)
    write_csv(ROOT/'results/all_training.csv',training)
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['reproduce','compare','summary']);p.add_argument('--seed',type=int)
    args=p.parse_args()
    if args.stage=='reproduce':reproduce()
    elif args.stage=='compare':compare_world(args.seed)
    else:summarize()

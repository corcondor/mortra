# Development smoke experiment: task-blind pretraining action selection

This file is fixed locally before the first new-policy outcome. It is not an
external/timestamped preregistration or a fresh confirmatory experiment.

## Exact scope
- Reuse stored fresh70-registration, seeds 73000000..73000007 (first 8 in fixed
  order), all 12 stored tasks/world. Historical/development worlds, not holdout.
- Initial training from zero, 3 selectors: original structural, frontier_t0,
  generic virtual_frontier with source 1 and singleton memory.
- Budgets 128, 512, 2048; nested checkpoints, no reset between budgets.
- No new NN, semantic features, task-dependent source, or oracle labels.
- During training, selectors see only the learned counts and current observation.
  SingletonMemory.advance ignores its observation; progress/acceptance raise.
- Same frozen recorder. Retain each selector's original node_visits bookkeeping.
- Identical downstream evaluation in all arms: original CachingSparsePlanner,
  OnlineTaskAgent, generic VirtualFrontierPolicy. Private snapshot copy per task;
  task cap and exploration cap 4096. Retain original final-step acceptance rule,
  but separately audit accepted-memory/reported-success discrepancies.
- Tasks were generated previously from the canonical 8192 map; not regenerated
  per arm; that reference map/snapshot and task list are NOT supplied to training.
- World/task/cap values fixed; no selective task removal or world replacement.
- Reference reproduction: all 8 structural 512 snapshots vs saved attributes,
  and all 96 historical generic episodes vs saved success/steps/exploration.
- Proposed comparisons are descriptive: mean task capped cost, successes,
  per-world means and differences, coverage, initial model path availability,
  cumulative training CPU, evaluation CPU, worst regressions.
- Total interaction metric for a 12-task batch reusing a learned snapshot:
  B + sum_t task_cost; per-task amortized cost B/12 + mean_t task_cost.
  Evaluation experience is NOT shared between tasks. Also report B+mean_cost for
  a hypothetical new training run per single task. Do not conflate these costs.
- Local exception/resource interruption is incomplete, not policy failure.
- Stop after these fixed worlds; do not optimize policies based on outcomes.
- Original GitHub source and historical artifacts are never edited.

## Numerical runtime
Local installed Python/NumPy/SciPy versions are recorded. They differ from
historical Actions versions. Exact reproduction is a gate; no silent claims of
bit-identical floating-point fields across different numerical libraries.
Six full algorithm/engine files are byte-checked against stored preflight hashes.
The StructuralLearner class is a verbatim selected-definition excerpt from the
frozen script (the original frozen loader also extracts that class using AST).
The local loader skips unrelated dependencies and side effects. All new code
and these explicitly identified local shims are included in the package.

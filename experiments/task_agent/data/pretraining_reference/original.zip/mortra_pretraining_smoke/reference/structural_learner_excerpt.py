class StructuralLearner:
    """
    General task-agnostic structural learner.
    Input: step(action) -> next_obs
    Constructs pure K_support (no visit counts on edge weights).
    """
    def __init__(self, num_actions):
        self.num_actions = num_actions
        self.state_to_id = {}
        self.id_to_state = []
        self.node_visits = {}       # u -> count
        self.action_visits = {}     # (u, a) -> count
        self.counts = {}            # (u, a) -> {v: count}
        self.dest_map = {}          # (u, a) -> modal v

    def get_or_add_id(self, state):
        if state not in self.state_to_id:
            idx = len(self.id_to_state)
            self.state_to_id[state] = idx
            self.id_to_state.append(state)
            return idx
        return self.state_to_id[state]

    def select_action(self, u):
        self.node_visits[u] = self.node_visits.get(u, 0) + 1
        # Priority 1: Untried actions at current node
        untried = [a for a in range(self.num_actions) if self.action_visits.get((u, a), 0) == 0]
        if untried:
            return untried[0] # Deterministic selection among untried
        
        # Priority 2: State-action with lowest visit count
        # Tie-breaker: lowest neighbor visit count
        best_a = 0
        best_score = 1e9
        for a in range(self.num_actions):
            n_ua = self.action_visits.get((u, a), 0)
            v = self.dest_map.get((u, a), u)
            n_v = self.node_visits.get(v, 0)
            score = n_ua * 10000.0 + n_v
            if score < best_score:
                best_score = score
                best_a = a
        return best_a

    def record_transition(self, u, a, v):
        self.action_visits[(u, a)] = self.action_visits.get((u, a), 0) + 1
        key = (u, a)
        if key not in self.counts:
            self.counts[key] = {}
        self.counts[key][v] = self.counts[key].get(v, 0) + 1
        self.dest_map[key] = max(self.counts[key].items(), key=lambda it: it[1])[0]

    def build_k_support(self):
        """Constructs K_support with equal weight per tried action."""
        N = len(self.id_to_state)
        K = np.zeros((N, N), dtype=float)
        for u in range(N):
            tried_acts = [a for a in range(self.num_actions) if (u, a) in self.counts]
            if not tried_acts:
                continue
            act_w = 1.0 / len(tried_acts)
            for a in tried_acts:
                v_set = list(self.counts[(u, a)].keys())
                prob_v = 1.0 / len(v_set)
                for v in v_set:
                    K[u, v] += act_w * prob_v
        return K

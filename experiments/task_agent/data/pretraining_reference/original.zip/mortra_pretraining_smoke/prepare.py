"""Freeze input slice and source/runtime manifest without running new policies."""
from pathlib import Path
from zipfile import ZipFile
import json, csv, sys, platform, hashlib
from datetime import datetime, timezone
import numpy, scipy
from io_utils import save_json, sha256
ROOT=Path(__file__).resolve().parent
SEEDS=list(range(73000000,73000008))
archive=Path('/mnt/data/fresh70-registration.zip')
with ZipFile(archive) as z:
    orig=json.loads(z.read('preflight.json'))
    records=[]
    for seed in SEEDS:
        for name in ('genome.json','tasks.json','snapshot_512.json','registration.json'):
            b=z.read(f'registration/{seed}/{name}')
            p=ROOT/'inputs'/str(seed)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
            records.append({'path':str(p.relative_to(ROOT)), 'sha256':sha256(p)})
    save_json(ROOT/'inputs/original_preflight.json',orig)
with open('/mnt/data/fresh70_episodes.csv',newline='') as f:
    baseline=[r for r in csv.DictReader(f) if int(r['seed']) in SEEDS and r['policy']=='virtual_frontier']
assert len(baseline)==96
save_json(ROOT/'inputs/reference_episodes.json',baseline)
checks={}
for name in ('core.py','exploration.py','online.py','online_eval.py','virtual_frontier.py'):
    key='experiments/task_agent/'+name
    checks[key]={'actual':sha256(ROOT/'vendor'/key),'expected':orig['source_sha256'][key]}
key='experiments/game_frontier_v11/world.py'
checks[key]={'actual':sha256(ROOT/'reference/world.py'),'expected':orig['source_sha256'][key]}
assert all(c['actual']==c['expected'] for c in checks.values())
save_json(ROOT/'manifest_before.json',{
    'fixed_at_utc':datetime.now(timezone.utc).isoformat(),
    'upstream_commit':'24c44da50aac2c084a91fdd9f6754f0429da9350',
    'scope':'historical development slice; not fresh confirmatory',
    'seeds':SEEDS, 'budgets':[128,512,2048], 'task_cap':4096,
    'registration_sha256':sha256(archive), 'inputs':records,
    'full_file_checks':checks,
    'structural_class_excerpt_source':'scripts/evaluate_cross_domain_generalization.py:83-149',
    'structural_class_excerpt_sha256':sha256(ROOT/'reference/structural_learner_excerpt.py'),
    'python':sys.version,'numpy':numpy.__version__,'scipy':scipy.__version__,
    'platform':platform.platform(), 'protocol_sha256':sha256(ROOT/'PROTOCOL.md'),
    'source_sha256':{str(p.relative_to(ROOT)):sha256(p) for p in sorted(ROOT.rglob('*.py'))},
})
print('Frozen inputs: 8 worlds, 96 tasks; 6 full source hashes match.')

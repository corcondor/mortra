# MORTRA 初期学習の方策切替：実装・小規模実行結果

## 何を実装したか

**初期学習で使う行動選択だけ**を、structural / frontier_t0 /
virtual_frontier に切り替える関数 `train_snapshots_with_policy` を追加した。
遷移記録、task semantics、既知経路planner、オンライン実行、q=0.90は変更していない。
これは新しい価値学習器・自己拡張機構・NNの実装ではない。

タスクなしの初期学習では `SingletonMemory.advance` が観測内容を読まずに常に0を返す。
既存virtual-frontierを `task_aware=False, task_source=False` で呼び、
未試行actionのsourceをすべて1にする。`progress` / `accepting` が呼ばれた場合は
例外にしている。環境は実行したactionの観測結果だけを学習器へ戻す。
oracle graph・oracle距離・将来taskの教師ラベルは作っていない。

## サンプルと固定した条件

旧fresh70の保存済み先頭8 world、seed 73000000〜73000007。
各12タスク、96タスク。学習予算128 / 512 / 2048、3学習方式で864比較episode。
この8 worldは新規holdoutではなく、**既に使われた開発用サンプル**。
実行前の条件は `PROTOCOL.md` と `manifest_before.json` に保存した。
外部サーバーで事前登録した確認実験ではない。

学習は空のモデルから始め、同一world内で予算に達した時点のモデルを保存する。
学習後は全条件で同じgeneric virtual-frontier + CachingSparsePlanner +
OnlineTaskAgentを使う。各タスクは学習済みモデルの独立コピーから開始する。
タスク生成元は歴史実験のcanonical 8192-stepモデルのままで、学習方法ごとに
タスクを作り直していない。このタスク生成上の条件づけは残る。

## 再現・検証

- 主要な元コード6ファイルは保存済みpreflightのSHA-256と完全一致。
  core / exploration / online / online_eval / virtual_frontier / world。
- 元の `tests/test_task_agent.py` もSHA-256一致、既存9テストを変更せず実行。
- 新規26件と合わせて **35/35 tests passed**。実行前・実行後のログを保存。
- 従来学習512手の8モデルは、状態、遷移、訪問数、辞書挿入順序が保存済みと完全一致。
- 保存済み96タスクのgeneric結果を成功判定・手数・探索手数まで **96/96完全再現**。
- 864比較episodeはすべて成功。
- 読み戻しで49,152学習遷移・65,489評価遷移を再生。
  全72学習checkpointと全864episodeが一致。終端記憶と成功判定の矛盾0件。
- 新コードを実行したのはこのローカル環境。GitHubへのpush、元実装の変更、
  過去結果の上書きは行っていない。

## 平均タスク手数（初期学習の手数はこの表に含まない）

| 初期学習予算 | 従来structural | frontier_t0学習 | virtual-frontier学習 |
|---:|---:|---:|---:|
| 128 | 193.469 | 193.802 | 193.802 |
| 512 | 22.781 | 21.271 | **17.063** |
| 2048 | 14.823 | **12.583** | **12.583** |

各セル96/96成功。512手条件のvirtual対従来は平均5.71875手、25.1029%減。
world単位では改善3 / 悪化0 / 同値5。task単位では改善17 / 悪化0 / 同値79。
同条件で、初期学習済みモデルにaccepting pathがあるtaskは77/96から90/96に増えた。
この数値は同じ初期学習予算・同じ後段方策での実測であり、oracle-sourceを学習できた証拠ではない。

悪化を隠していない。128手のvirtual学習は平均0.333手悪化し、task単位では
改善6 / 悪化6 / 同値84（最大悪化17手）。2048手ではfrontier_t0とvirtualが
評価費用で同値であり、virtualが常に優れているという結論はない。

## 初期学習も含めた経験費用

同じ学習済みモデルを12タスクに再利用する仮定では、
1タスク当たり償却費用 = B/12 + 平均タスク手数。
評価タスク間の追加経験の共有はしない。

| B | structural | frontier_t0 | virtual_frontier |
|---:|---:|---:|---:|
|128|204.135|204.469|204.469|
|512|65.448|63.938|59.729|
|2048|185.490|183.250|183.250|

512手条件ではこの総経験費用も8.7379%減った。
2048手は学習後のタスクだけなら最短だが、12タスクへの償却費用では512手より高い。
1タスクごとに初期学習をやり直す仮定の `B + task_cost` もCSVへ別記してある。

## 計算費用と制限

512手条件の計測CPU合計（8world分の学習＋96タスク実行）は、
structural 4.783秒、virtual 6.369秒。**環境操作回数は減ったがCPU時間は増えた。**
これはログ・チェックを含むローカル固定順実行の工学的参考値。
タスク前の到達可能性診断、入出力準備や再現確認全体などはこの合計に含まない。
メソッドの総時間に関する一般的な優位性は主張しない。

数値環境: Python 3.13.5 / NumPy 2.3.5 / SciPy 1.17.0 / pytest 9.0.2。
元のActions環境とは異なる。上記96行の再現ゲートで差を検査した。
8worldという小標本の記述的開発結果。母集団の改善や統計的有意性は主張しない。

最後のworldは、2worldをまとめて実行したコマンドの45秒上限で最初の試行が中断した。
完了済み7worldは再実行していない。中断したworldだけ同じコード・条件で再実行し完了。
中断出力は `results/interrupted_73000007_attempt1/`、記録は
`results/infrastructure_retry.json` に保存。方策失敗には数えていない。
sourceやseed、予算、評価条件は変更していない。

## ファイル

- 実装: `vendor/experiments/task_agent/pretraining.py`
- 実行: `run_smoke.py`
- 再実行ラッパー: `reproduce_local.py`
- 結果: `results/summary.json`, `aggregate.csv`, `all_episodes.csv`,
  `world_means.csv`, `task_pairs.csv`, `all_training.csv`
- 入力: `inputs/`（8worldのgenome、固定task、参照512モデル、参照episode）
- 各worldの学習・実行trace、72個の学習snapshot、テストログ・XML、監査を同梱。

### 元コードの利用方法

主要5つのtask-agentファイルはそのままimportしている。
Engineはバイト一致する元 `reference/world.py` から `validate` / `Engine` 定義だけをASTで読み込む。
StructuralLearnerは元スクリプトのクラス定義をそのまま抜粋してASTで読み込む。
元スクリプトの標準出力置換・ログ作成・関係しない環境のimportは実行しない。
`reference_loader.py` と `vendor/experiments/game_frontier_v{1,11}/` の2つのshimは
この自己完結パッケージ用で、リポジトリへ上書きするものではない。

MORTRAの元checkoutで使う場合、追加するのは `pretraining.py` のみ。
そのファイルは元repositoryの通常importで動く構造になっている。
ただし元checkout内での統合テストやGitHub Actions実行は今回はしていない。

### 自己完結パッケージを再実行

```sh
python -m pip install -r requirements-tested.txt
python reproduce_local.py --output ../mortra_pretraining_rerun
```

結果フォルダを新規作成し、35テスト、96行の歴史結果再現、8world比較、trace監査、
同梱864結果行との照合を行う。時間列は照合対象外。
異なる数値ライブラリでは近接同点の選択が変わる可能性があるため、環境を記録する。

## 結論

初期学習への接続は実装でき、動作・再現ゲートを通過した。
今回の512手条件ではvirtual-frontier学習による改善が観測された。
ただし128手では改善せず、2048手ではfrontier_t0と同値、CPU時間も増える。
新しいsource推定・自己拡張・数学や視覚への一般化は、この実験の対象外。

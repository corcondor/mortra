"""Re-execute in a new directory without overwriting the supplied results.

Usage: python reproduce_local.py --output ../mortra_pretraining_rerun
Requires the versions in requirements-tested.txt for the closest numerical replay.
"""
from __future__ import annotations
import argparse,csv,json,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();dest=args.output.resolve()
    if dest.exists():raise FileExistsError('output must not already exist: '+str(dest))
    if ROOT in dest.parents:raise ValueError('place the rerun outside the supplied bundle')
    dest.mkdir(parents=True)
    for dirname in ('vendor','reference','inputs','tests'):
        shutil.copytree(ROOT/dirname,dest/dirname,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for path in ROOT.iterdir():
        if path.is_file() and (path.suffix in ('.py','.md') or path.name=='manifest_before.json'):
            shutil.copy2(path,dest/path.name)
    results=dest/'results';results.mkdir()
    env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
    def run(arguments,name):
        with (results/name).open('w',encoding='utf-8') as log:
            process=subprocess.Popen([sys.executable,*arguments],cwd=dest,env=env,
                                     stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            assert process.stdout is not None
            for line in process.stdout:
                print(line,end='',flush=True);log.write(line);log.flush()
            code=process.wait()
            if code:raise subprocess.CalledProcessError(code,arguments)
    run(['-m','pytest','tests','-q','--junitxml=results/tests.xml'],'tests.log')
    run(['run_smoke.py','reproduce'],'reproduction.log')
    for seed in range(73000000,73000008):
        run(['run_smoke.py','compare','--seed',str(seed)],f'run_{seed}.log')
    run(['run_smoke.py','summary'],'summary.log')
    run(['audit_results.py'],'audit.log')
    def read(path):
        with path.open(newline='',encoding='utf-8') as handle:return list(csv.DictReader(handle))
    old=read(ROOT/'results/all_episodes.csv');new=read(results/'all_episodes.csv')
    key=lambda r:(r['seed'],r['method'],r['budget'],r['task_id'])
    reference={key(r):r for r in old}
    fields=['success','task_steps','capped_steps','exploration_steps','starts_in_model','initial_known_states','final_known_states','failure_reason','final_memory_accepting']
    mismatches=[{'key':key(r),'fields':[f for f in fields if r[f]!=reference[key(r)][f]]}
                for r in new if any(r[f]!=reference[key(r)][f] for f in fields)]
    check={'rows':len(new),'reference_rows':len(old),'mismatches':mismatches,
           'passed':len(new)==len(old) and not mismatches,
           'note':'Timing fields excluded. Different SciPy versions can change near-tie argmax behavior.'}
    (results/'bundle_comparison.json').write_text(json.dumps(check,indent=2)+'\n')
    print(json.dumps(check,indent=2))
    if not check['passed']:raise RuntimeError('new run does not match supplied comparison rows')

if __name__=='__main__':main()
